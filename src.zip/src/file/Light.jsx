import React from "react";


function Light(){
    return(
        <>
        </>
    )
}

export default Light;