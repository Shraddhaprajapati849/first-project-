import React from "react";

function Silicon(){
    return(
        <>
        </>
    )
}

export default Silicon;
